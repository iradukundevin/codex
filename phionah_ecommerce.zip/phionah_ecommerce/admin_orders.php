<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT o.id, u.username as customer, p.name as product, o.order_date, o.status 
        FROM orders o 
        JOIN users u ON o.customer_id = u.id 
        JOIN products p ON o.product_id = p.id";
$result = $conn->query($sql);
?>

<h2>System Orders</h2>
<table>
    <tr>
        <th>Order ID</th>
        <th>Customer</th>
        <th>Product</th>
        <th>Date</th>
        <th>Status</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['customer']; ?></td>
        <td><?php echo $row['product']; ?></td>
        <td><?php echo $row['order_date']; ?></td>
        <td><?php echo $row['status']; ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
