<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<h2>Shop Products</h2>
<div class="product-grid">
    <?php while($row = $result->fetch_assoc()): ?>
    <div class="product-card">
        <img src="<?php echo $row['image_path']; ?>" alt="<?php echo $row['name']; ?>" style="height:150px; object-fit:cover;">
        <h3><?php echo $row['name']; ?></h3>
        <p>$<?php echo $row['price']; ?></p>
        <p><small>Location: <?php echo $row['location']; ?></small></p>
        <a href="product_detail.php?id=<?php echo $row['id']; ?>"><button>View Details</button></a>
    </div>
    <?php endwhile; ?>
</div>

<?php include 'footer.php'; ?>
