    </div>
    <footer>
        <p>&copy; 2026 Phionah E-Commerce. All rights reserved.</p>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>
