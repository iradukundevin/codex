<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$seller_id = $_SESSION['user_id'];
$sql = "SELECT * FROM products WHERE seller_id = $seller_id";
$result = $conn->query($sql);
?>

<h2>Seller Dashboard</h2>
<p>Manage your inventory and location.</p>

<div class="product-grid" style="margin-bottom: 30px;">
    <div class="product-card">
        <h3>Add Product</h3>
        <p>Upload new product photos and details.</p>
        <a href="seller_upload.php"><button>Upload Now</button></a>
    </div>
    <div class="product-card">
        <h3>Set Location</h3>
        <p>Update your business location for customers.</p>
        <a href="seller_location.php"><button>Update Location</button></a>
    </div>
</div>

<h3>Your Products</h3>
<table>
    <tr>
        <th>Name</th>
        <th>Price</th>
        <th>Location</th>
        <th>Action</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['name']; ?></td>
        <td>$<?php echo $row['price']; ?></td>
        <td><?php echo $row['location']; ?></td>
        <td><a href="seller_edit_product.php?id=<?php echo $row['id']; ?>">Edit</a></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
