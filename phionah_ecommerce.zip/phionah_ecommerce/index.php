<?php include 'header.php'; ?>
<h2>Welcome to Phionah E-Commerce</h2>
<p>Your one-stop shop for all your needs. Whether you are a seller looking to reach more customers or a customer looking for the best products, we have you covered.</p>

<div class="product-grid">
    <!-- Featured Products could go here -->
    <div class="product-card">
        <h3>Seller Services</h3>
        <p>Upload your products and reach thousands of customers.</p>
        <a href="register.php?role=seller"><button>Join as Seller</button></a>
    </div>
    <div class="product-card">
        <h3>Customer Experience</h3>
        <p>Browse, order, and review quality products.</p>
        <a href="register.php?role=customer"><button>Start Shopping</button></a>
    </div>
</div>
<?php include 'footer.php'; ?>
