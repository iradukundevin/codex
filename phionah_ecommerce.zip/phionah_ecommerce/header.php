<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phionah E-Commerce</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Phionah E-Commerce</h1>
    </header>
    <nav>
        <a href="index.php">Home</a>
        <?php if(!isset($_SESSION['user_id'])): ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php else: ?>
            <?php if($_SESSION['role'] == 'admin'): ?>
                <a href="admin_dashboard.php">Admin Dashboard</a>
            <?php elseif($_SESSION['role'] == 'seller'): ?>
                <a href="seller_dashboard.php">Seller Dashboard</a>
            <?php else: ?>
                <a href="customer_shop.php">Shop</a>
                <a href="customer_orders.php">My Orders</a>
            <?php endif; ?>
            <a href="logout.php">Logout (<?php echo $_SESSION['username']; ?>)</a>
        <?php endif; ?>
    </nav>
    <div class="container">
