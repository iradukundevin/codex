<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
?>

<h2>Admin Dashboard</h2>
<p>Welcome, Admin. Here you can manage the entire system.</p>

<div class="product-grid">
    <div class="product-card">
        <h3>User Management</h3>
        <p>View and manage all registered users.</p>
        <a href="admin_users.php"><button>Manage Users</button></a>
    </div>
    <div class="product-card">
        <h3>Product Oversight</h3>
        <p>Review products uploaded by sellers.</p>
        <a href="admin_products.php"><button>Manage Products</button></a>
    </div>
    <div class="product-card">
        <h3>Order Reports</h3>
        <p>View all transactions across the platform.</p>
        <a href="admin_orders.php"><button>View Orders</button></a>
    </div>
</div>

<?php include 'footer.php'; ?>
