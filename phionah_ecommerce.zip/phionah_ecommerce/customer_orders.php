<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['user_id'];
$sql = "SELECT o.id, p.name as product, o.order_date, o.status 
        FROM orders o 
        JOIN products p ON o.product_id = p.id 
        WHERE o.customer_id = $customer_id";
$result = $conn->query($sql);
?>

<h2>My Orders</h2>
<table>
    <tr>
        <th>Order ID</th>
        <th>Product</th>
        <th>Date</th>
        <th>Status</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['product']; ?></td>
        <td><?php echo $row['order_date']; ?></td>
        <td><?php echo $row['status']; ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
