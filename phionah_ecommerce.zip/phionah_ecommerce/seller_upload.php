<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $location = $_POST['location'];
    $seller_id = $_SESSION['user_id'];

    // Basic file upload handling
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);
    
    if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO products (seller_id, name, description, price, image_path, location) 
                VALUES ($seller_id, '$name', '$description', $price, '$target_file', '$location')";
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color:green;'>Product uploaded successfully!</p>";
        } else {
            echo "<p style='color:red;'>Database Error: " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color:red;'>Sorry, there was an error uploading your file.</p>";
    }
}
?>

<h2>Upload Product</h2>
<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>Product Name:</label>
        <input type="text" name="name" required>
    </div>
    <div class="form-group">
        <label>Description:</label>
        <textarea name="description" required></textarea>
    </div>
    <div class="form-group">
        <label>Price ($):</label>
        <input type="number" step="0.01" name="price" required>
    </div>
    <div class="form-group">
        <label>Location:</label>
        <input type="text" name="location" required>
    </div>
    <div class="form-group">
        <label>Product Image:</label>
        <input type="file" name="product_image" required>
    </div>
    <button type="submit">Upload Product</button>
</form>

<?php include 'footer.php'; ?>
