<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT p.*, u.username as seller_name FROM products p JOIN users u ON p.seller_id = u.id";
$result = $conn->query($sql);
?>

<h2>Manage Products</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Seller</th>
        <th>Price</th>
        <th>Location</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['seller_name']; ?></td>
        <td>$<?php echo $row['price']; ?></td>
        <td><?php echo $row['location']; ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
