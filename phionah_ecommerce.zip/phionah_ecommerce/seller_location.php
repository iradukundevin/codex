<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $location = $_POST['location'];
    $sql = "UPDATE users SET location = '$location' WHERE id = $user_id";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Location updated successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
    }
}

$sql = "SELECT location FROM users WHERE id = $user_id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
?>

<h2>Set Your Location</h2>
<form method="post">
    <div class="form-group">
        <label>Current Location:</label>
        <input type="text" name="location" value="<?php echo $user['location']; ?>" required>
    </div>
    <button type="submit">Update Location</button>
</form>

<?php include 'footer.php'; ?>
