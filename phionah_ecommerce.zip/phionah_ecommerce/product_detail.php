<?php 
include 'db_config.php';
include 'header.php'; 

if (!isset($_GET['id'])) {
    header("Location: customer_shop.php");
    exit();
}

$product_id = $_GET['id'];
$customer_id = $_SESSION['user_id'];

// Handle Order
if (isset($_POST['place_order'])) {
    $sql = "INSERT INTO orders (customer_id, product_id) VALUES ($customer_id, $product_id)";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Order placed successfully!</p>";
    }
}

// Handle Comment
if (isset($_POST['submit_comment'])) {
    $comment = $_POST['comment'];
    $rating = $_POST['rating'];
    $sql = "INSERT INTO comments (product_id, customer_id, comment, rating) VALUES ($product_id, $customer_id, '$comment', $rating)";
    $conn->query($sql);
}

$sql = "SELECT p.*, u.username as seller_name FROM products p JOIN users u ON p.seller_id = u.id WHERE p.id = $product_id";
$result = $conn->query($sql);
$product = $result->fetch_assoc();
?>

<h2><?php echo $product['name']; ?></h2>
<div style="display: flex; gap: 20px;">
    <img src="<?php echo $product['image_path']; ?>" style="width: 300px;">
    <div>
        <p><strong>Price:</strong> $<?php echo $product['price']; ?></p>
        <p><strong>Seller:</strong> <?php echo $product['seller_name']; ?></p>
        <p><strong>Location:</strong> <?php echo $product['location']; ?></p>
        <p><strong>Description:</strong><br><?php echo $product['description']; ?></p>
        
        <form method="post">
            <button type="submit" name="place_order">Order Now</button>
            <a href="<?php echo $product['image_path']; ?>" download><button type="button" style="background-color: #007bff;">Download Image</button></a>
        </form>
    </div>
</div>

<hr>
<h3>Comments & Reviews</h3>
<form method="post" style="margin-bottom: 20px;">
    <div class="form-group">
        <label>Rating (1-5):</label>
        <input type="number" name="rating" min="1" max="5" required>
    </div>
    <div class="form-group">
        <label>Comment:</label>
        <textarea name="comment" required></textarea>
    </div>
    <button type="submit" name="submit_comment">Post Comment</button>
</form>

<?php
$sql = "SELECT c.*, u.username FROM comments c JOIN users u ON c.customer_id = u.id WHERE c.product_id = $product_id ORDER BY c.created_at DESC";
$comments = $conn->query($sql);
while($c = $comments->fetch_assoc()):
?>
    <div style="border-bottom: 1px solid #ddd; padding: 10px 0;">
        <strong><?php echo $c['username']; ?></strong> (Rating: <?php echo $c['rating']; ?>/5)<br>
        <?php echo $c['comment']; ?><br>
        <small><?php echo $c['created_at']; ?></small>
    </div>
<?php endwhile; ?>

<?php include 'footer.php'; ?>
