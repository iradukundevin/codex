# Codex Telematics - Design Notes

## Sawa Telematics Website Analysis

### Key Sections Identified:
1. **Navigation Header** - Logo, Solutions, Industries, Products, About, Pricing, Blog, CTA buttons
2. **Hero Section** - Large headline "Africa's Fleet Intelligence Layer", tagline, two CTA buttons, live dashboard preview
3. **Stats Section** - 3,000+ Connected Vehicles, 95% Client Retention, 10M+ Data Points/Day
4. **Live Dashboard Demo** - Interactive map showing fleet overview with vehicle alerts
5. **The Problem Section** - 4 key pain points (fuel costs, breakdowns, driver misconduct, fragmented data)
6. **Solutions Section** - 6 feature cards (Real-Time Tracking, Fuel Monitoring, Predictive Maintenance, Driver Behavior, Digital Logbook, API Integrations)
7. **Product Ecosystem** - 6+ product cards with status badges (Live, In Progress, Coming 2027)
8. **FAQ Section** - Accordion with common questions
9. **Footer** - Links, contact info, social media

### Design Elements:
- **Color Scheme**: Deep blue background (#1e3a8a or similar), white/light text, yellow/gold accent (#fbbf24 or similar)
- **Typography**: Bold display font for headlines, clean sans-serif for body
- **Layout**: Asymmetric, modern, with interactive elements
- **Interactive Elements**: Expandable FAQs, hover effects, smooth scrolling

### Content to Replace:
- "Sawa Telematics" → "Codex"
- Company-specific stats (will use placeholder or similar values)
- Specific client logos (will create generic trusted brands section)
- Contact details (will use generic contact info)

## Design Philosophy for Codex

**Approach**: Modern, professional, tech-forward with emphasis on data intelligence and fleet management. The design should convey trust, innovation, and operational efficiency.

**Color Palette**:
- Primary: Deep Blue (#1e40af or #1e3a8a)
- Accent: Vibrant Yellow/Gold (#fbbf24 or #fcd34d)
- Background: White with subtle gradients
- Text: Dark slate for readability

**Typography**:
- Display: Bold, modern sans-serif (e.g., Poppins, Outfit)
- Body: Clean, readable sans-serif (e.g., Inter, Roboto)

**Key Design Principles**:
1. Trust through clarity - Clean, organized information hierarchy
2. Innovation through motion - Subtle animations and transitions
3. Efficiency through design - Intuitive navigation and clear CTAs
4. Data-driven aesthetic - Visual elements that suggest analytics and intelligence
