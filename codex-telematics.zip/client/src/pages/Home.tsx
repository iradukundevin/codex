import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronRight, Menu, X, Zap, TrendingUp, AlertCircle, BarChart3, Smartphone, Settings } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

/**
 * Design Philosophy: Warm Gradient Sophistication
 * - Deep navy to warm charcoal gradients
 * - Overlapping cards with floating elements
 * - Organic dividers and flowing shapes
 * - Bold Outfit headlines with warm Poppins body text
 */

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 text-2xl font-bold text-primary hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-cyan-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">C</span>
            </div>
            Codex
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#solutions" className="text-sm font-medium hover:text-primary transition-colors">
              Solutions
            </a>
            <a href="#industries" className="text-sm font-medium hover:text-primary transition-colors">
              Industries
            </a>
            <a href="#products" className="text-sm font-medium hover:text-primary transition-colors">
              Products
            </a>
            <a href="#faq" className="text-sm font-medium hover:text-primary transition-colors">
              FAQ
            </a>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
              Sign In
            </Button>
            <Button className="bg-primary hover:bg-sky-600 text-white">
              Book a Demo
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-white">
            <div className="container py-4 flex flex-col gap-4">
              <a href="#solutions" className="text-sm font-medium hover:text-primary">
                Solutions
              </a>
              <a href="#industries" className="text-sm font-medium hover:text-primary">
                Industries
              </a>
              <a href="#products" className="text-sm font-medium hover:text-primary">
                Products
              </a>
              <a href="#faq" className="text-sm font-medium hover:text-primary">
                FAQ
              </a>
              <Button variant="outline" className="w-full border-primary text-primary">
                Sign In
              </Button>
              <Button className="w-full bg-primary hover:bg-sky-600 text-white">
                Book a Demo
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-32 relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663490947174/Jd6wsuTsAChpwGH7LF5pB3/hero-background-GmH9EBXwGDGRYkwPyBu52P.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-white/80 to-transparent" />

        <div className="container grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-in fade-in duration-1000">
            <div className="inline-block px-4 py-2 bg-orange-100 rounded-full">
              <p className="text-sm font-semibold text-primary">Trusted by leading fleets across Africa</p>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold leading-tight">
              Rwanda's Leading <span className="text-primary">Fleet Management</span> System
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg">
              We don't just track vehicles. We turn movement into intelligence — reducing costs, preventing failures, and making African fleets more profitable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="bg-primary hover:bg-sky-600 text-white">
                Book a Free Demo
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5">
                Explore Solutions
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div>
                <p className="text-3xl font-bold text-primary">3,000+</p>
                <p className="text-sm text-muted-foreground">Connected Vehicles</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">95%</p>
                <p className="text-sm text-muted-foreground">Client Retention</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">10M+</p>
                <p className="text-sm text-muted-foreground">Data Points/Day</p>
              </div>
            </div>
          </div>

          {/* Dashboard Preview */}
          <div className="relative animate-in fade-in slide-in-from-right duration-1000 delay-200">
            <div className="rounded-2xl overflow-hidden shadow-2xl border border-border">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663490947174/Jd6wsuTsAChpwGH7LF5pB3/dashboard-mockup-mWaFGBSPYnjcnpwUeL7jQD.webp"
                alt="Live Dashboard"
                className="w-full h-auto"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
          </div>
        </div>
      </section>

      {/* The Problem Section */}
      <section
        id="industries"
        className="py-20 md:py-32 relative overflow-hidden"
        style={{
          backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663490947174/Jd6wsuTsAChpwGH7LF5pB3/problem-section-bg-LAXfCshW8ApSFxwBjyZYjK.webp')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-white/90 to-white/70" />

        <div className="container space-y-16">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Most African fleets are operating <span className="text-primary">blind</span>.
            </h2>
            <p className="text-lg text-muted-foreground">
              The data exists. The cost is real. But without intelligence, fleets can't act on either.
            </p>
          </div>

          {/* Problem Cards */}
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-l-4 border-l-primary hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">30-45%</h3>
                  <p className="text-muted-foreground">
                    of operating cost is fuel — and most of it leaks undetected through theft, waste, and inefficiency.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-primary hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Days Lost</h3>
                  <p className="text-muted-foreground">
                    Unplanned failures happen without warning, paralyzing operations and destroying revenue for days at a time.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-primary hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Zap className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Driver Misconduct</h3>
                  <p className="text-muted-foreground">
                    Harsh driving accelerates wear, increases accident risk, and drives up insurance costs — all without accountability.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-primary hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Fragmented Data</h3>
                  <p className="text-muted-foreground">
                    Your data exists across devices, spreadsheets, and paper logs — siloed, unreliable, and impossible to act on.
                  </p>
                </div>
              </div>
            </Card>
          </div>

          <div className="bg-primary/5 border border-primary/20 rounded-xl p-8 max-w-2xl">
            <p className="text-lg font-semibold text-foreground">
              This is a multi-billion-dollar structural inefficiency. <span className="text-primary">Codex exists to eliminate it.</span>
            </p>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section id="solutions" className="py-20 md:py-32 bg-gradient-to-b from-white to-orange-50">
        <div className="container space-y-16">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Everything your fleet needs to <span className="text-primary">perform</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              From real-time tracking to predictive intelligence — built for African roads and networks.
            </p>
          </div>

          {/* Solution Cards Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Zap size={32} />,
                title: "Real-Time Tracking",
                description: "Know where every vehicle is, always. Optimized for low-connectivity African networks.",
              },
              {
                icon: <TrendingUp size={32} />,
                title: "Fuel Monitoring",
                description: "Detect theft, track consumption, and cut fuel waste with precise level sensors and alerts.",
              },
              {
                icon: <AlertCircle size={32} />,
                title: "Predictive Maintenance",
                description: "Move from reactive repairs to data-driven maintenance schedules that prevent costly downtime.",
              },
              {
                icon: <Smartphone size={32} />,
                title: "Driver Behavior",
                description: "Score every driver on speed, braking, idling, and harsh events. Coach with data, not guesswork.",
              },
              {
                icon: <BarChart3 size={32} />,
                title: "Digital Logbook",
                description: "Replace paper logs with automated, tamper-proof digital records for every trip and event.",
              },
              {
                icon: <Settings size={32} />,
                title: "API Integrations",
                description: "Connect Codex to your ERP, dispatch tools, insurance systems, or any third-party platform.",
              },
            ].map((solution, idx) => (
              <Card
                key={idx}
                className="p-8 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-border/50 group"
              >
                <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <div className="text-primary">{solution.icon}</div>
                </div>
                <h3 className="text-xl font-bold mb-3">{solution.title}</h3>
                <p className="text-muted-foreground mb-6">{solution.description}</p>
                <a href="#" className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
                  Learn more <ChevronRight size={18} />
                </a>
              </Card>
            ))}
          </div>

          <div className="text-center pt-8">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/5">
              View All Solutions
            </Button>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 md:py-32 relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663490947174/Jd6wsuTsAChpwGH7LF5pB3/solutions-pattern-e84Y7d7BXgWTN3xqKaFGTN.webp')",
            backgroundSize: "400px",
            backgroundPosition: "center",
            opacity: 0.3,
          }}
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-white/95 to-white/90" />

        <div className="container space-y-16">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Beyond telematics — a full fleet <span className="text-primary">services ecosystem</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              The Codex platform is the intelligence core. Around it, we're building the services that make fleet operations financially sustainable.
            </p>
          </div>

          {/* Product Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { emoji: "📡", title: "Monitoring Platform", status: "Live", description: "Web + iOS app. Your entire fleet, one screen." },
              { emoji: "🛡️", title: "Usage-Based Insurance", status: "In Progress", description: "Premiums driven by actual driving behavior." },
              { emoji: "⛽", title: "Fuel Financing", status: "In Progress", description: "Fuel credit tied to your telematics data." },
              { emoji: "💳", title: "Driver Card", status: "In Progress", description: "Verified driver record + incentive wallet." },
              { emoji: "🚌", title: "ETA Public Transport", status: "Live", description: "Arrival predictions via QR or USSD." },
              { emoji: "📋", title: "Traffic Penalties", status: "In Progress", description: "Track and resolve fines automatically." },
            ].map((product, idx) => (
              <Card
                key={idx}
                className="p-8 border border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 group"
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl">{product.emoji}</span>
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                    product.status === "Live"
                      ? "bg-green-100 text-green-700"
                      : product.status === "In Progress"
                      ? "bg-orange-100 text-orange-700"
                      : "bg-gray-100 text-gray-700"
                  }`}>
                    {product.status}
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-2">{product.title}</h3>
                <p className="text-muted-foreground">{product.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 md:py-32 bg-gradient-to-b from-orange-50 to-white">
        <div className="container max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Frequently Asked <span className="text-primary">Questions</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Everything you need to know about Codex and how it can transform your fleet operations.
            </p>
          </div>

          {/* FAQ Items */}
          <div className="space-y-4">
            {[
              {
                q: "Is Codex just a GPS tracking system?",
                a: "No. Codex is Africa's fleet intelligence layer. While GPS tracking is part of it, we process raw data into actionable intelligence — fuel anomalies, maintenance predictions, driver behavior scoring, and more.",
              },
              {
                q: "What African markets do you currently serve?",
                a: "We operate across East and Central Africa, with a focus on Kenya, Rwanda, Uganda, and Tanzania. We're expanding rapidly to serve more markets.",
              },
              {
                q: "Does Codex work on low-connectivity networks?",
                a: "Yes. Our system is specifically optimized for African networks with intermittent connectivity. Data syncs automatically when connection is restored.",
              },
              {
                q: "Does Codex support electric vehicles?",
                a: "Yes. Our platform supports all vehicle types, including electric vehicles, with specialized metrics for EV fleet management.",
              },
              {
                q: "What does onboarding look like?",
                a: "Onboarding is simple: install our hardware in your vehicles, connect to our platform, and start receiving insights within hours. Our team guides you through every step.",
              },
              {
                q: "Can Codex integrate with our existing software?",
                a: "Absolutely. We offer comprehensive API integrations with ERP systems, dispatch tools, insurance platforms, and custom solutions.",
              },
            ].map((item, idx) => (
              <Card key={idx} className="p-6 border border-border/50 hover:border-primary/30 transition-colors">
                <details className="group cursor-pointer">
                  <summary className="flex items-center justify-between font-semibold text-lg">
                    <span>{item.q}</span>
                    <ChevronRight className="group-open:rotate-90 transition-transform" size={20} />
                  </summary>
                  <p className="mt-4 text-muted-foreground leading-relaxed">{item.a}</p>
                </details>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663490947174/Jd6wsuTsAChpwGH7LF5pB3/cta-gradient-n68soZdDMLNpEEGHM55v5b.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-white/85 to-transparent" />

        <div className="container max-w-2xl">
          <div className="space-y-8 animate-in fade-in duration-1000">
            <div>
              <p className="text-sm font-semibold text-primary mb-4">READY TO TRANSFORM YOUR FLEET?</p>
              <h2 className="text-4xl md:text-5xl font-bold leading-tight">
                Let's build something <span className="text-primary italic">extraordinary</span> together.
              </h2>
            </div>
            <p className="text-lg text-muted-foreground">
              Partner with a team that's passionate about your success and dedicated to delivering measurable results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="bg-primary hover:bg-sky-600 text-white">
                Book Your Free Demo
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5">
                Contact Sales
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-16 md:py-20">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-foreground font-bold">C</span>
                </div>
                <span className="font-bold text-lg">Codex</span>
              </div>
              <p className="text-white/70">Rwanda's Leading Fleet Management System</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="mailto:codexgroupltd@codex.com" className="hover:text-white transition-colors">codexgroupltd@codex.com</a></li>
                <li><a href="tel:+250786282856" className="hover:text-white transition-colors">+250 786 282 856</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-white/70">
            <p>&copy; 2026 Codex. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
